import React from 'react'
import Title from './../../shared/ui/Title';

export default function Problems() {
  return (
    <section className='py-20'>
        <Title>Asosiy muammo</Title>
      
    </section>
  )
}
